drop table if exists USER;

create table USER (
    ID integer primary key,
    USER_ROLE text,
    USER_NAME text,
    USER_PASS text
);

